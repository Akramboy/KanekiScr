import os

os.system("python -m pip install --upgrade pip") 
os.system("pip install telethon")
os.system("pip install colorama")
os.system("pip install requests")
os.system("pip install python-cfonts")
os.system("pip install get-mac")
os.system("cls" if os.name=='nt' else 'clear')

print ('All Packages Installed Sucessfully')
